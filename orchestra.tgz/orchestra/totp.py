"""TOTP (RFC 6238): коды из приложения-аутентификатора, 6 цифр, шаг 30 секунд."""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
import time
from urllib.parse import quote

STEP = 30


def new_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip('=')


def code_at(secret: str, step: int) -> str:
    key = base64.b32decode(secret + '=' * (-len(secret) % 8))
    digest = hmac.new(key, struct.pack('>Q', step), hashlib.sha1).digest()
    off = digest[-1] & 0x0F
    return f'{(struct.unpack(">I", digest[off:off + 4])[0] & 0x7FFFFFFF) % 1_000_000:06d}'


def verify(secret: str, code: str, last_step: int = 0, now: float | None = None) -> int | None:
    """Шаг, на котором код верен (допуск ±1 шаг), или None. Шаги не новее last_step не принимаются."""
    code = ''.join(ch for ch in str(code or '') if ch.isdigit())
    if len(code) != 6:
        return None
    current = int((now or time.time()) // STEP)
    for step in (current, current - 1, current + 1):
        if step > last_step and hmac.compare_digest(code_at(secret, step), code):
            return step
    return None


def uri(secret: str, login: str, issuer: str) -> str:
    return (f'otpauth://totp/{quote(issuer)}:{quote(login)}?secret={secret}'
            f'&issuer={quote(issuer)}&digits=6&period={STEP}')


def qr_svg(text: str) -> str:
    """QR-код для приложения-аутентификатора в виде SVG (рисуется на сервере, без внешних сервисов)."""
    import io
    import segno
    buf = io.BytesIO()
    segno.make(text, error='m').save(buf, kind='svg', scale=5, border=2, dark='#111', light='#fff', xmldecl=False, svgns=True)
    return buf.getvalue().decode()
