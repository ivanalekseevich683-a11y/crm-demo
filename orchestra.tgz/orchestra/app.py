"""Оркестратор агентов: доска задач, запуск агентов в отдельных учётных записях, проверка и слияние.

Агенты (Claude, Codex, Gemini, Grok) работают под своими пользователями сервера и не видят чужих
ключей и истории. Общий у них только git-репозиторий проекта: каждый делает задачу в своей ветке task-<id>,
ведущий агент проверяет результат, вы сливаете принятое в main кнопкой на доске.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import sqlite3
import subprocess
import threading
import time
from contextlib import contextmanager
from pathlib import Path

from argon2 import PasswordHasher
from argon2.exceptions import VerificationError
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, JSONResponse

import totp

DATA = Path(os.environ.get('ORCH_DATA', '/srv/orchestra/data'))
REPO = os.environ.get('ORCH_REPO', '/srv/orchestra/repo.git')
MERGE_DIR = Path(os.environ.get('ORCH_MERGE', '/srv/orchestra/merge'))
RUNNER = os.environ.get('ORCH_RUNNER', '/opt/orchestra/bin/run-agent')
SUDO = os.environ.get('ORCH_SUDO', 'sudo -n -H -u agent-{agent}').split()
COOKIE_SECURE = os.environ.get('ORCH_COOKIE_SECURE', '1') == '1'
STATIC = Path(__file__).parent / 'static'
AGENTS = {
    'claude': 'Claude Code', 'codex': 'Codex (ChatGPT)', 'gemini': 'Gemini CLI', 'grok': 'Grok Build',
}
ROLE_HINT = {
    'claude': 'ведущий: архитектура, сложный код, проверка работы других',
    'codex': 'код: реализация функций и исправление ошибок',
    'gemini': 'тесты, документация, разбор больших файлов',
    'grok': 'исследование, поиск решений, черновики',
}
ph = PasswordHasher()
DB_LOCK = threading.Lock()


# ---------- база ----------
def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DATA / 'orchestra.db', timeout=30, isolation_level=None)
    conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def tx():
    with DB_LOCK:
        conn = db()
        try:
            conn.execute('BEGIN IMMEDIATE')
            yield conn
            conn.execute('COMMIT')
        except Exception:
            conn.execute('ROLLBACK')
            raise
        finally:
            conn.close()


def q(sql: str, args=()) -> list[dict]:
    conn = db()
    try:
        return [dict(r) for r in conn.execute(sql, args).fetchall()]
    finally:
        conn.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parent_id INTEGER REFERENCES tasks(id),
  title TEXT NOT NULL,
  goal TEXT NOT NULL,
  kind TEXT NOT NULL,              -- team (общая задача) | sub (подзадача агенту)
  agent TEXT,
  status TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  branch TEXT,
  output TEXT NOT NULL DEFAULT '',
  diffstat TEXT NOT NULL DEFAULT '',
  review TEXT NOT NULL DEFAULT '',
  created REAL NOT NULL,
  updated REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER, ts REAL NOT NULL, text TEXT NOT NULL
);
"""
DEFAULTS = {'lead': 'claude', 'parallel': '2', 'review': '1', 'auto_merge': '0',
            'enabled': json.dumps(['claude', 'codex', 'gemini']), 'upstream': ''}


def setting(key: str) -> str:
    r = q('SELECT value FROM settings WHERE key = ?', (key,))
    return r[0]['value'] if r else DEFAULTS.get(key, '')


def set_setting(key: str, value: str) -> None:
    with tx() as c:
        c.execute('INSERT INTO settings(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
                  (key, value))


def log(task_id: int | None, text: str) -> None:
    with tx() as c:
        c.execute('INSERT INTO events(task_id, ts, text) VALUES (?, ?, ?)', (task_id, time.time(), text))


def upd(task_id: int, **f) -> None:
    f['updated'] = time.time()
    cols = ', '.join(f'{k} = ?' for k in f)
    with tx() as c:
        c.execute(f'UPDATE tasks SET {cols} WHERE id = ?', (*f.values(), task_id))


def task(task_id: int) -> dict:
    r = q('SELECT * FROM tasks WHERE id = ?', (task_id,))
    if not r:
        raise HTTPException(404, 'Задача не найдена')
    return r[0]


def enabled_agents() -> list[str]:
    try:
        return [a for a in json.loads(setting('enabled')) if a in AGENTS]
    except ValueError:
        return []


# ---------- запуск агентов ----------
def run_agent(agent: str, task_id: int, mode: str, prompt: str, timeout: int = 4000) -> tuple[int, str]:
    cmd = [p.format(agent=agent) for p in SUDO] + [RUNNER, agent, str(task_id), mode]
    try:
        p = subprocess.run(cmd, input=prompt, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout + ('\n' + p.stderr if p.stderr.strip() else ''))[-60000:]
    except subprocess.TimeoutExpired:
        return 124, '@@ERROR агент не ответил за отведённое время'


def git(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(['git', *args], cwd=cwd or MERGE_DIR, capture_output=True, text=True, timeout=300)


def merge_ready() -> None:
    if not (MERGE_DIR / '.git').exists():
        subprocess.run(['git', 'clone', '-q', REPO, str(MERGE_DIR)], check=True)
    git('config', 'user.name', 'orchestra'); git('config', 'user.email', 'orchestra@orchestra.local')
    git('fetch', '-q', '--prune', 'origin')
    git('reset', '-q', '--hard'); git('clean', '-fdq')
    git('checkout', '-q', '-B', 'main', 'origin/main')


def branch_diff(branch: str, limit: int = 50000) -> str:
    merge_ready()
    d = git('diff', f'origin/main...origin/{branch}').stdout
    return d if len(d) <= limit else d[:limit] + '\n… (diff обрезан)'


def project_context() -> str:
    try:
        merge_ready()
        files = git('ls-files').stdout.splitlines()
    except Exception:
        files = []
    head = '\n'.join(files[:300]) + ('\n…' if len(files) > 300 else '')
    return f'Файлы проекта (ветка main):\n{head or "(пока пусто)"}'


PLAN_PROMPT = """Ты ведущий в команде ИИ-агентов, которые вместе работают над одним git-проектом.
Агенты не общаются друг с другом: каждый делает свою подзадачу в отдельной ветке от main, потом ты проверяешь работу.
Доступные агенты и их сильные стороны:
{agents}

Цель от пользователя:
{goal}

{context}

Разбей цель на 1–6 независимых подзадач, чтобы агенты могли делать их параллельно и не правили одни и те же файлы.
Каждая подзадача — законченный кусок работы с понятным результатом. Пиши задания по-русски, конкретно: какие файлы,
что сделать, как проверить. Ничего не меняй в проекте сам.
Ответь ТОЛЬКО JSON-массивом без пояснений:
[{{"agent": "<одно из: {names}>", "title": "<коротко>", "instructions": "<подробное задание>"}}]"""

WORK_PROMPT = """Ты агент «{agent}» в команде ИИ-агентов. Ты работаешь в git-репозитории проекта, в своей ветке.
Общая цель команды: {goal}

Твоя подзадача: {title}
{instructions}
{rework}
Правила: меняй только то, что нужно для подзадачи; если в проекте есть тесты — запусти их;
коммитить и пушить не нужно, это сделают за тебя. В конце коротко напиши по-русски, что сделано и как проверить."""

REVIEW_PROMPT = """Ты ведущий и проверяешь работу агента «{agent}». Репозиторий открыт на его ветке, можешь запускать тесты, но ничего не меняй.
Подзадача: {title}
{instructions}

Отчёт агента:
{output}

Изменения относительно main:
{diff}

Проверь, что подзадача выполнена, код корректен и ничего не сломано. Первой строкой ответа напиши ровно
ОДОБРЕНО или ДОРАБОТАТЬ, дальше — коротко по-русски, что не так и что исправить."""


def plan(parent: dict) -> None:
    lead = setting('lead')
    names = enabled_agents()
    agents = '\n'.join(f'- {a}: {ROLE_HINT[a]}' for a in names)
    prompt = PLAN_PROMPT.format(agents=agents, goal=parent['goal'], context=project_context(), names=', '.join(names))
    log(parent['id'], f'Ведущий ({AGENTS[lead]}) разбирает задачу')
    code, out = run_agent(lead, parent['id'], 'plan', prompt)
    m = re.search(r'\[\s*\{.*\}\s*\]', out, re.S)
    items = []
    if m:
        try:
            items = [i for i in json.loads(m.group(0)) if isinstance(i, dict) and i.get('agent') in names]
        except ValueError:
            items = []
    if not items:
        upd(parent['id'], status='failed', output=out)
        log(parent['id'], 'Ведущий не смог разбить задачу на подзадачи. Ответ сохранён в задаче.')
        return
    now = time.time()
    with tx() as c:
        for i in items[:6]:
            c.execute('INSERT INTO tasks(parent_id, title, goal, kind, agent, status, output, created, updated) '
                      "VALUES (?, ?, ?, 'sub', ?, 'queued', '', ?, ?)",
                      (parent['id'], str(i.get('title') or 'Подзадача')[:200], str(i.get('instructions') or '')[:20000],
                       i['agent'], now, now))
    upd(parent['id'], status='running', output=out)
    log(parent['id'], f'План готов: {len(items[:6])} подзадач(и)')


def work(t: dict) -> None:
    parent = task(t['parent_id']) if t['parent_id'] else t
    rework = f'\nЭто доработка. Замечания проверяющего:\n{t["review"]}\n' if t['attempts'] and t['review'] else ''
    prompt = WORK_PROMPT.format(agent=AGENTS[t['agent']], goal=parent['goal'], title=t['title'],
                                instructions=t['goal'], rework=rework)
    log(t['id'], f'{AGENTS[t["agent"]]} начал работу (попытка {t["attempts"] + 1})')
    code, out = run_agent(t['agent'], t['id'], 'work', prompt)
    branch = re.search(r'@@BRANCH (\S+)', out)
    diffstat = out.split('@@DIFFSTAT', 1)[1].strip() if '@@DIFFSTAT' in out else ''
    report = out.split('@@BRANCH', 1)[0].strip()
    if code != 0 and not branch:
        upd(t['id'], status='failed', output=report, attempts=t['attempts'] + 1)
        log(t['id'], f'Агент завершился с ошибкой (код {code})')
        return
    if not branch:
        upd(t['id'], status='failed', output=report + '\n\n(Агент не внёс изменений в проект)', attempts=t['attempts'] + 1)
        log(t['id'], 'Агент не внёс изменений')
        return
    nxt = 'needs_review' if setting('review') == '1' else 'approved'
    upd(t['id'], status=nxt, output=report, diffstat=diffstat, branch=branch.group(1), attempts=t['attempts'] + 1)
    log(t['id'], 'Работа сдана' + (', ждёт проверки ведущим' if nxt == 'needs_review' else ''))
    if nxt == 'approved' and setting('auto_merge') == '1':
        merge_task(t['id'])


def review(t: dict) -> None:
    lead = setting('lead')
    prompt = REVIEW_PROMPT.format(agent=AGENTS[t['agent']], title=t['title'], instructions=t['goal'],
                                  output=t['output'][-8000:], diff=branch_diff(t['branch']))
    log(t['id'], f'Проверяет {AGENTS[lead]}')
    code, out = run_agent(lead, t['id'], 'review', prompt)
    verdict = out.strip().splitlines()[0].upper() if out.strip() else ''
    if 'ОДОБРЕНО' in verdict:
        upd(t['id'], status='approved', review=out.strip())
        log(t['id'], 'Ведущий одобрил')
        if setting('auto_merge') == '1':
            merge_task(t['id'])
    elif t['attempts'] < 3:
        upd(t['id'], status='queued', review=out.strip())
        log(t['id'], 'Ведущий вернул на доработку')
    else:
        upd(t['id'], status='failed', review=out.strip())
        log(t['id'], 'После трёх попыток задача не принята')


def merge_task(task_id: int) -> tuple[bool, str]:
    t = task(task_id)
    if not t['branch']:
        return False, 'У задачи нет ветки с изменениями'
    with MERGE_LOCK:
        merge_ready()
        r = git('merge', '--no-ff', '-m', f'Задача {t["id"]}: {t["title"]} ({AGENTS.get(t["agent"], "")})', f'origin/{t["branch"]}')
        if r.returncode != 0:
            git('merge', '--abort')
            upd(task_id, status='conflict')
            log(task_id, 'Конфликт при слиянии: изменения пересекаются с уже принятыми')
            return False, 'Конфликт с уже принятыми изменениями. Нажмите «Переделать от свежего main».'
        p = git('push', '-q', 'origin', 'main')
        if p.returncode != 0:
            return False, 'Не удалось сохранить main: ' + p.stderr[-300:]
        up = setting('upstream')
        if up:
            u = git('push', '-q', up, 'main')
            if u.returncode != 0:
                log(task_id, 'Не удалось отправить main во внешний репозиторий: ' + re.sub(r'//[^@]+@', '//***@', u.stderr[-300:]))
        git('push', '-q', 'origin', '--delete', t['branch'])
    upd(task_id, status='merged')
    log(task_id, 'Изменения приняты в main')
    return True, 'Слито в main'


def refresh_parents() -> None:
    for p in q("SELECT id FROM tasks WHERE kind = 'team' AND status = 'running'"):
        subs = q('SELECT status FROM tasks WHERE parent_id = ?', (p['id'],))
        if subs and all(s['status'] in ('approved', 'merged', 'failed', 'conflict', 'cancelled') for s in subs):
            upd(p['id'], status='done')
            log(p['id'], 'Все подзадачи завершены')


# ---------- планировщик ----------
MERGE_LOCK = threading.Lock()
BUSY: set[str] = set()
BUSY_LOCK = threading.Lock()


def _start(agent: str, fn, t: dict, status: str) -> None:
    upd(t['id'], status=status)

    def go():
        try:
            fn(task(t['id']))
        except Exception as e:  # noqa: BLE001 — ошибка одной задачи не должна останавливать остальные
            upd(t['id'], status='failed')
            log(t['id'], f'Внутренняя ошибка: {e}')
        finally:
            with BUSY_LOCK:
                BUSY.discard(agent)
    threading.Thread(target=go, daemon=True).start()


def tick() -> None:
    refresh_parents()
    limit = max(1, int(setting('parallel') or 2))
    lead = setting('lead')
    jobs = []
    for t in q("SELECT * FROM tasks WHERE status = 'plan_queued' ORDER BY id"):
        jobs.append((lead, plan, t, 'planning'))
    for t in q("SELECT * FROM tasks WHERE status = 'needs_review' ORDER BY id"):
        jobs.append((lead, review, t, 'reviewing'))
    for t in q("SELECT * FROM tasks WHERE status = 'queued' ORDER BY id"):
        jobs.append((t['agent'], work, t, 'running'))
    for agent, fn, t, status in jobs:
        with BUSY_LOCK:
            if len(BUSY) >= limit or agent in BUSY:
                continue
            BUSY.add(agent)
        _start(agent, fn, t, status)


def scheduler() -> None:
    while True:
        try:
            tick()
        except Exception as e:  # noqa: BLE001
            print('scheduler:', e, flush=True)
        time.sleep(3)


# ---------- приложение ----------
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
HITS: dict[str, list[float]] = {}


@app.on_event('startup')
def startup() -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    conn = db()
    conn.executescript(SCHEMA)
    # после перезапуска незавершённые шаги ставятся в очередь заново
    conn.execute("UPDATE tasks SET status = 'queued' WHERE status = 'running'")
    conn.execute("UPDATE tasks SET status = 'needs_review' WHERE status = 'reviewing'")
    conn.execute("UPDATE tasks SET status = 'plan_queued' WHERE status = 'planning'")
    conn.close()
    if os.environ.get('ORCH_SCHEDULER', '1') == '1':
        threading.Thread(target=scheduler, daemon=True).start()


@app.middleware('http')
async def guard(request: Request, call_next):
    if request.method not in ('GET', 'HEAD') and request.headers.get('x-orch') != '1':
        return JSONResponse({'error': 'Запрос отклонён'}, 403)
    path = request.url.path
    if path.startswith('/api/') and path not in ('/api/login', '/api/me'):
        tok = request.cookies.get('orch')
        if not tok or not q('SELECT 1 FROM sessions WHERE token = ? AND created > ?', (tok, time.time() - 30 * 86400)):
            return JSONResponse({'error': 'Нужно войти'}, 401)
    resp = await call_next(request)
    resp.headers['X-Frame-Options'] = 'DENY'
    resp.headers['X-Content-Type-Options'] = 'nosniff'
    resp.headers['Referrer-Policy'] = 'no-referrer'
    resp.headers['Content-Security-Policy'] = "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'"
    return resp


@app.get('/')
def index():
    return FileResponse(STATIC / 'index.html')


@app.get('/app.js')
def app_js():
    return FileResponse(STATIC / 'app.js', media_type='application/javascript')


@app.get('/api/me')
def me(request: Request):
    tok = request.cookies.get('orch')
    ok = bool(tok and q('SELECT 1 FROM sessions WHERE token = ?', (tok,)))
    return {'auth': ok}


@app.post('/api/login')
async def login(request: Request, response: Response):
    ip = request.headers.get('x-forwarded-for', request.client.host if request.client else '').split(',')[0]
    now = time.time()
    HITS[ip] = [h for h in HITS.get(ip, []) if h > now - 600]
    if len(HITS[ip]) >= 10:
        raise HTTPException(429, 'Слишком много попыток. Подождите 10 минут.')
    d = await request.json()
    try:
        ph.verify(setting('pass_hash'), str(d.get('password') or ''))
    except (VerificationError, Exception):
        HITS[ip].append(now)
        raise HTTPException(400, 'Неверный пароль')
    secret, enabled = setting('totp_secret'), setting('totp_enabled') == '1'
    if not secret:
        secret = totp.new_secret()
        set_setting('totp_secret', secret)
    code = str(d.get('code') or '')
    if not enabled:
        uri = totp.uri(secret, 'admin', 'Оркестр агентов')
        if not code:
            return JSONResponse({'error': 'Подключите Google Authenticator', 'code': '2fa_enroll', 'secret': secret,
                                 'qr': totp.qr_svg(uri), 'uri': uri}, 401)
    step = totp.verify(secret, code, int(setting('totp_last') or 0))
    if step is None:
        HITS[ip].append(now)
        raise HTTPException(400, 'Неверный код из приложения')
    set_setting('totp_last', str(step))
    set_setting('totp_enabled', '1')
    tok = secrets.token_urlsafe(32)
    with tx() as c:
        c.execute('INSERT INTO sessions(token, created) VALUES (?, ?)', (tok, now))
    response.set_cookie('orch', tok, httponly=True, secure=COOKIE_SECURE, samesite='strict', max_age=30 * 86400)
    return {'ok': True}


@app.post('/api/logout')
def logout(request: Request, response: Response):
    with tx() as c:
        c.execute('DELETE FROM sessions WHERE token = ?', (request.cookies.get('orch'),))
    response.delete_cookie('orch')
    return {'ok': True}


@app.get('/api/state')
def state():
    tasks = q('SELECT id, parent_id, title, kind, agent, status, attempts, branch, created, updated FROM tasks '
              'ORDER BY id DESC LIMIT 300')
    with BUSY_LOCK:
        busy = sorted(BUSY)
    return {'tasks': tasks, 'busy': busy, 'agents': AGENTS, 'roles': ROLE_HINT,
            'settings': {k: setting(k) for k in ('lead', 'parallel', 'review', 'auto_merge', 'enabled')},
            'upstream_set': bool(setting('upstream'))}


@app.get('/api/tasks/{task_id}')
def task_detail(task_id: int):
    t = task(task_id)
    t['events'] = q('SELECT ts, text FROM events WHERE task_id = ? ORDER BY id', (task_id,))
    t['subs'] = q('SELECT id, title, agent, status, attempts FROM tasks WHERE parent_id = ? ORDER BY id', (task_id,))
    return t


@app.get('/api/tasks/{task_id}/diff')
def task_diff(task_id: int):
    t = task(task_id)
    if not t['branch']:
        return {'diff': ''}
    with MERGE_LOCK:
        return {'diff': branch_diff(t['branch'], 200000)}


@app.post('/api/tasks')
async def create_task(request: Request):
    d = await request.json()
    goal = str(d.get('goal') or '').strip()
    if not goal:
        raise HTTPException(400, 'Опишите задачу')
    agent = d.get('agent') or ''
    now = time.time()
    title = str(d.get('title') or goal.splitlines()[0])[:200]
    with tx() as c:
        if agent:
            if agent not in AGENTS:
                raise HTTPException(400, 'Неизвестный агент')
            cur = c.execute("INSERT INTO tasks(title, goal, kind, agent, status, created, updated) "
                            "VALUES (?, ?, 'sub', ?, 'queued', ?, ?)", (title, goal, agent, now, now))
        else:
            cur = c.execute("INSERT INTO tasks(title, goal, kind, status, created, updated) "
                            "VALUES (?, ?, 'team', 'plan_queued', ?, ?)", (title, goal, now, now))
        tid = cur.lastrowid
    log(tid, 'Задача создана' + (f', исполнитель: {AGENTS[agent]}' if agent else ', команда: ведущий распределит работу'))
    return {'id': tid}


@app.post('/api/tasks/{task_id}/{action}')
def task_action(task_id: int, action: str):
    t = task(task_id)
    if action == 'merge':
        ids = [s['id'] for s in q("SELECT id FROM tasks WHERE parent_id = ? AND status = 'approved' ORDER BY id", (task_id,))] \
            if t['kind'] == 'team' else [task_id]
        if not ids:
            raise HTTPException(400, 'Нет одобренных изменений для слияния')
        msgs = [merge_task(i)[1] for i in ids]
        return {'ok': True, 'message': '; '.join(dict.fromkeys(msgs))}
    if action == 'approve':
        upd(task_id, status='approved'); log(task_id, 'Одобрено вручную')
    elif action == 'retry':
        upd(task_id, status='plan_queued' if t['kind'] == 'team' else 'queued'); log(task_id, 'Запущено заново')
    elif action == 'cancel':
        with tx() as c:
            c.execute("UPDATE tasks SET status = 'cancelled' WHERE (id = ? OR parent_id = ?) AND status IN "
                      "('queued', 'plan_queued', 'needs_review', 'approved', 'failed', 'conflict')", (task_id, task_id))
        log(task_id, 'Отменено')
    else:
        raise HTTPException(404, 'Неизвестное действие')
    return {'ok': True}


@app.get('/api/agents')
def agents_status():
    out = {}
    for a in AGENTS:
        code, txt = run_agent(a, 0, 'check', '', timeout=60)
        m = re.search(r'@@STATUS (\S+)\s*(.*)', txt)
        out[a] = {'status': m.group(1) if m else 'error', 'version': (m.group(2).strip() if m else txt[-200:])}
    return out


@app.post('/api/settings')
async def save_settings(request: Request):
    d = await request.json()
    if 'lead' in d and d['lead'] in AGENTS:
        set_setting('lead', d['lead'])
    if 'parallel' in d:
        set_setting('parallel', str(min(4, max(1, int(d['parallel'])))))
    for k in ('review', 'auto_merge'):
        if k in d:
            set_setting(k, '1' if d[k] else '0')
    if 'enabled' in d:
        set_setting('enabled', json.dumps([a for a in d['enabled'] if a in AGENTS]))
    if 'upstream' in d:
        set_setting('upstream', str(d['upstream']).strip())
    return {'ok': True}


@app.get('/api/project')
def project():
    with MERGE_LOCK:
        merge_ready()
        logtxt = git('log', '--oneline', '-20').stdout
        files = git('ls-files').stdout.splitlines()
    return {'log': logtxt, 'files': len(files), 'path': REPO}


if __name__ == '__main__':
    import sys
    if sys.argv[1:2] == ['set-password']:
        DATA.mkdir(parents=True, exist_ok=True)
        c = db(); c.executescript(SCHEMA); c.close()
        pw = '-'.join(secrets.token_urlsafe(4)[:4] for _ in range(4))
        set_setting('pass_hash', ph.hash(pw))
        set_setting('totp_enabled', '0'); set_setting('totp_secret', '')
        with tx() as c2:
            c2.execute('DELETE FROM sessions')
        print(f'PASSWORD {pw}')
