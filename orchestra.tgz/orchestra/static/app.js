'use strict';
const $ = (s, r = document) => r.querySelector(s);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const STATUS = {
  plan_queued: 'ждёт разбора', planning: 'ведущий планирует', queued: 'в очереди', running: 'в работе',
  needs_review: 'ждёт проверки', reviewing: 'на проверке', approved: 'одобрено', merged: 'в main',
  done: 'готово', failed: 'не получилось', conflict: 'конфликт', cancelled: 'отменено',
};
const AGENT_STATUS = { ready: 'готов', no_login: 'нужен вход', not_installed: 'не установлен', error: 'ошибка проверки' };
let TAB = 'tasks', SEL = null, STATE = null, AGENTS_INFO = null;

async function api(path, opts = {}) {
  const o = { method: opts.method || 'GET', headers: { 'X-Orch': '1' } };
  if (opts.body) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opts.body); }
  const r = await fetch('/api' + path, o);
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 && path !== '/login') { showAuth(); throw new Error('Нужно войти'); }
  if (!r.ok) { const e = new Error(d.error || d.detail || 'Ошибка ' + r.status); e.data = d; throw e; }
  return d;
}
function toast(t) { const el = $('#toast'); el.textContent = t; el.style.display = 'block'; clearTimeout(el._t); el._t = setTimeout(() => { el.style.display = 'none'; }, 3500); }
const pill = (s) => `<span class="pill s-${esc(s)}">${esc(STATUS[s] || s)}</span>`;
const when = (ts) => new Date(ts * 1000).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

function showAuth() { $('#app').hidden = true; $('#auth').hidden = false; }
$('#login').onsubmit = async (e) => {
  e.preventDefault();
  $('#lerr').textContent = '';
  try {
    await api('/login', { method: 'POST', body: { password: $('#pw').value, code: $('#code').value } });
    $('#auth').hidden = true; start();
  } catch (ex) {
    if (ex.data?.code === '2fa_enroll') {
      $('#enroll').hidden = false;
      $('#enroll').innerHTML = `<p>Установите на телефон Google Authenticator, нажмите «+» → «Сканировать QR-код»:</p>
        <div class="qr">${ex.data.qr}</div><p class="mut">Или введите ключ вручную: <code>${esc(ex.data.secret)}</code></p>`;
      $('#codebox').hidden = false; $('#code').focus();
    } else {
      if (/код/i.test(ex.message)) $('#codebox').hidden = false;
      $('#lerr').textContent = ex.message;
    }
  }
};
$('#logout').onclick = async () => { await api('/logout', { method: 'POST' }).catch(() => {}); location.reload(); };
document.querySelectorAll('nav button').forEach((b) => { b.onclick = () => { TAB = b.dataset.tab; document.querySelectorAll('nav button').forEach((x) => x.classList.toggle('on', x === b)); render(); }; });

async function refresh() { STATE = await api('/state'); }

function taskList() {
  const all = STATE.tasks;
  const tops = all.filter((t) => !t.parent_id);
  return tops.map((t) => {
    const subs = all.filter((s) => s.parent_id === t.id).reverse();
    return `<div class="item ${SEL === t.id ? 'on' : ''}" data-id="${t.id}">
      <div class="row"><b>#${t.id}</b> ${pill(t.status)} <span class="mut">${t.kind === 'team' ? 'команда' : esc(STATE.agents[t.agent])}</span></div>
      <div>${esc(t.title)}</div>
      ${subs.map((s) => `<div class="sub row" data-id="${s.id}">↳ #${s.id} ${pill(s.status)} <span class="mut">${esc(STATE.agents[s.agent])}</span> ${esc(s.title)}</div>`).join('')}
    </div>`;
  }).join('') || '<p class="mut">Задач пока нет. Опишите первую слева.</p>';
}

async function renderTasks(m) {
  const enabled = JSON.parse(STATE.settings.enabled || '[]');
  m.innerHTML = `<div class="grid">
    <div style="display:grid;gap:16px;align-content:start">
      <form class="card" id="newtask">
        <h2>Новая задача</h2>
        <label>Что нужно сделать<textarea id="goal" placeholder="Например: добавь в CRM выгрузку заказ-нарядов в Excel с фильтром по датам" required></textarea></label>
        <label>Кто делает<select id="who"><option value="">Команда: ведущий разобьёт задачу и раздаст агентам</option>
          ${enabled.map((a) => `<option value="${a}">Только ${esc(STATE.agents[a])}</option>`).join('')}</select></label>
        <button class="btn pri">Поставить задачу</button>
      </form>
      <div class="card"><h2>Задачи</h2><div class="list" id="tlist">${taskList()}</div></div>
    </div>
    <div class="card" id="detail"><p class="mut">Выберите задачу, чтобы увидеть ход работы, отчёты агентов и изменения.</p></div>
  </div>`;
  $('#newtask').onsubmit = async (e) => {
    e.preventDefault();
    const r = await api('/tasks', { method: 'POST', body: { goal: $('#goal').value, agent: $('#who').value } });
    SEL = r.id; toast('Задача поставлена'); await refresh(); render();
  };
  bindList();
  if (SEL) showDetail(SEL);
}
function bindList() {
  document.querySelectorAll('#tlist [data-id]').forEach((el) => {
    el.onclick = (e) => { e.stopPropagation(); SEL = +el.dataset.id; document.querySelectorAll('#tlist .item').forEach((x) => x.classList.toggle('on', +x.dataset.id === SEL)); showDetail(SEL); };
  });
}

async function showDetail(id) {
  const box = $('#detail'); if (!box) return;
  const t = await api('/tasks/' + id);
  const canMerge = t.kind === 'team' ? t.subs.some((s) => s.status === 'approved') : t.status === 'approved';
  box.innerHTML = `<div class="row"><h2>#${t.id} ${esc(t.title)}</h2> ${pill(t.status)}</div>
    <div class="mut">${t.kind === 'team' ? 'Командная задача' : 'Исполнитель: ' + esc(STATE.agents[t.agent])}${t.attempts ? ' · попыток: ' + t.attempts : ''}${t.branch ? ' · ветка ' + esc(t.branch) : ''}</div>
    <pre>${esc(t.goal)}</pre>
    <div class="row">
      ${canMerge ? '<button class="btn pri sm" data-act="merge">Слить в main</button>' : ''}
      ${t.branch && t.status !== 'merged' ? '<button class="btn sm" data-act="diff">Показать изменения</button>' : ''}
      ${['needs_review', 'failed', 'conflict'].includes(t.status) && t.branch ? '<button class="btn sm" data-act="approve">Одобрить вручную</button>' : ''}
      ${['failed', 'conflict', 'approved', 'done'].includes(t.status) ? `<button class="btn sm" data-act="retry">${t.status === 'conflict' ? 'Переделать от свежего main' : 'Запустить заново'}</button>` : ''}
      ${!['merged', 'cancelled', 'running', 'planning', 'reviewing'].includes(t.status) ? '<button class="btn sm" data-act="cancel">Отменить</button>' : ''}
    </div>
    ${t.subs.length ? `<div class="list">${t.subs.map((s) => `<div class="item" data-sub="${s.id}"><div class="row">#${s.id} ${pill(s.status)} <span class="mut">${esc(STATE.agents[s.agent])}</span></div><div>${esc(s.title)}</div></div>`).join('')}</div>` : ''}
    ${t.diffstat ? `<h2>Изменённые файлы</h2><pre>${esc(t.diffstat)}</pre>` : ''}
    ${t.review ? `<h2>Проверка ведущим</h2><pre>${esc(t.review)}</pre>` : ''}
    ${t.output ? `<h2>${t.kind === 'team' ? 'План ведущего' : 'Отчёт агента'}</h2><pre>${esc(t.output)}</pre>` : ''}
    <div id="diffbox"></div>
    <h2>Ход работы</h2><div class="ev">${t.events.map((e) => `<div><span class="mut">${when(e.ts)}</span> ${esc(e.text)}</div>`).join('')}</div>`;
  box.querySelectorAll('[data-sub]').forEach((el) => { el.onclick = () => { SEL = +el.dataset.sub; showDetail(SEL); }; });
  box.querySelectorAll('[data-act]').forEach((b) => {
    b.onclick = async () => {
      b.disabled = true;
      try {
        if (b.dataset.act === 'diff') {
          const d = await api(`/tasks/${id}/diff`);
          $('#diffbox').innerHTML = `<h2>Изменения</h2><pre class="diff">${esc(d.diff || 'Изменений нет')}</pre>`;
        } else {
          const r = await api(`/tasks/${id}/${b.dataset.act}`, { method: 'POST' });
          toast(r.message || 'Готово'); await refresh(); render();
        }
      } catch (ex) { toast(ex.message); } finally { b.disabled = false; }
    };
  });
}

async function renderAgents(m) {
  const s = STATE.settings, enabled = JSON.parse(s.enabled || '[]');
  m.innerHTML = `<div class="card"><h2>Агенты</h2>
    <p class="mut">Каждый агент — отдельный пользователь сервера: у него своя папка, свой вход и своя история. Общий у всех только репозиторий проекта.</p>
    <div style="overflow-x:auto"><table><tr><th>Агент</th><th>Роль</th><th>Состояние</th><th>Включён</th></tr>
    ${Object.entries(STATE.agents).map(([a, n]) => `<tr><td><b>${esc(n)}</b>${STATE.busy.includes(a) ? ' <span class="pill s-running">работает</span>' : ''}</td><td class="mut">${esc(STATE.roles[a])}</td>
      <td id="st-${a}" class="mut">${AGENTS_INFO ? esc((AGENT_STATUS[AGENTS_INFO[a].status] || AGENTS_INFO[a].status) + ' ' + AGENTS_INFO[a].version) : 'проверяю…'}</td>
      <td><input type="checkbox" data-en="${a}" ${enabled.includes(a) ? 'checked' : ''} style="width:auto"></td></tr>`).join('')}</table></div>
    <h2>Как выполнить вход</h2>
    <p class="mut">Один раз на каждого агента, в Termius на этом сервере. Команда покажет ссылку: откройте её на телефоне, войдите в свой аккаунт и при необходимости вставьте код обратно.</p>
    <div class="list">
      <div>Claude: <code>orchestra-login claude</code></div>
      <div>Codex (ChatGPT): <code>orchestra-login codex</code></div>
      <div>Gemini (Google): <code>orchestra-login gemini</code></div>
      <div>Grok (SuperGrok): <code>orchestra-login grok</code></div>
    </div></div>
    <form class="card" id="sets"><h2>Настройки команды</h2>
      <label>Ведущий (разбивает задачи и проверяет работу)<select id="lead">${Object.entries(STATE.agents).map(([a, n]) => `<option value="${a}" ${s.lead === a ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>
      <label>Сколько агентов работают одновременно<select id="par">${[1, 2, 3, 4].map((n) => `<option ${+s.parallel === n ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <label class="row" style="color:var(--fg)"><input type="checkbox" id="rev" style="width:auto" ${s.review === '1' ? 'checked' : ''}> Ведущий проверяет работу каждого агента</label>
      <label class="row" style="color:var(--fg)"><input type="checkbox" id="am" style="width:auto" ${s.auto_merge === '1' ? 'checked' : ''}> Сливать в main сразу после одобрения</label>
      <button class="btn pri">Сохранить</button></form>`;
  $('#sets').onsubmit = async (e) => {
    e.preventDefault();
    const en = [...document.querySelectorAll('[data-en]')].filter((x) => x.checked).map((x) => x.dataset.en);
    await api('/settings', { method: 'POST', body: { lead: $('#lead').value, parallel: +$('#par').value, review: $('#rev').checked, auto_merge: $('#am').checked, enabled: en } });
    toast('Сохранено'); await refresh();
  };
  if (!AGENTS_INFO) { AGENTS_INFO = await api('/agents').catch(() => null); if (TAB === 'agents') renderAgents(m); }
}

async function renderProject(m) {
  m.innerHTML = '<div class="card"><p class="mut">Загружаю…</p></div>';
  const p = await api('/project');
  m.innerHTML = `<div class="card"><h2>Проект</h2>
    <p class="mut">Общий git-репозиторий агентов: <code>${esc(p.path)}</code>, файлов в main: ${p.files}.</p>
    <h2>Последние изменения в main</h2><pre>${esc(p.log || 'Пока пусто')}</pre></div>
    <form class="card" id="up"><h2>Внешний репозиторий (GitHub)</h2>
    <p class="mut">Если указать адрес с токеном, принятые изменения будут сразу отправляться туда. Формат: <code>https://ТОКЕН@github.com/владелец/репозиторий.git</code>. ${STATE.upstream_set ? 'Сейчас адрес задан.' : 'Сейчас не задан.'}</p>
    <input id="upurl" placeholder="https://...@github.com/.../....git" autocomplete="off"><button class="btn pri">Сохранить</button></form>`;
  $('#up').onsubmit = async (e) => { e.preventDefault(); await api('/settings', { method: 'POST', body: { upstream: $('#upurl').value } }); toast('Сохранено'); await refresh(); };
}

async function render() {
  const m = $('#main');
  if (TAB === 'tasks') await renderTasks(m);
  else if (TAB === 'agents') await renderAgents(m);
  else await renderProject(m);
}

async function start() {
  $('#app').hidden = false;
  await refresh(); render();
  setInterval(async () => {
    if (TAB !== 'tasks' || document.activeElement?.id === 'goal' || $('#goal')?.value) return;
    await refresh().catch(() => {});
    const l = $('#tlist'); if (l) { l.innerHTML = taskList(); bindList(); }
    if (SEL && !$('#diffbox')?.innerHTML) showDetail(SEL);
  }, 5000);
}

api('/me').then((r) => (r.auth ? start() : showAuth())).catch(showAuth);
